valueCategory = ["Bahari" 10; "Budaya" 20; "Cagar Alam" 30; "Pusat Perbelanjaan" 25; "Taman Hiburan" 15; "Tempat Ibadah" 50];
cityPicked = ["Semarang"];
weightCriteria = [4 2 9];

main(valueCategory, cityPicked, weightCriteria)